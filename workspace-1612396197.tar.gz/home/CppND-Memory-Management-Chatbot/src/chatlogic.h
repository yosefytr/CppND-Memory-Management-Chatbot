#ifndef CHATLOGIC_H_
#define CHATLOGIC_H_

#include <vector>
#include <string>
#include "chatgui.h"
#include <wx/setup.h>

// forward declarations
class ChatBot;
class GraphEdge;
class GraphNode;

class ChatLogic
{
private:
    //// STUDENT CODE
    ////

    // data handles (owned)
    //std::vector<GraphNode *> _nodes;
    //std::vector<GraphEdge *> _edges;

   //std::unique_ptr<GraphEdige> _edges = std::make_unique<GraphEdge>id;

//https://stackoverflow.com/questions/39102028/how-to-return-vector-of-pointers-and-ownership-c11
//std::vector<std::unique_ptr<animal>> will work fine : 
//returning a function-local value will move it, not copy it (or only if moving is not available).
    
   std::vector<std::unique_ptr<GraphNode>> _nodes;
   //std::vector<std::unique_ptr<GraphEdge>> _edges;
  //   _chatLogic = std::make_unique<ChatLogic>();
  //_nodes = std::make_unique<GraphNode>

    ////
    //// EOF STUDENT CODE

    // data handles (not owned)
    GraphNode *_currentNode;

    //std::unique_ptr<GraphNode> *_currentNodeOwned;
    
    ChatBot *_chatBot;
    ChatBotPanelDialog *_panelDialog;  //to own ChatLogic Pointer?

    // proprietary type definitions
    typedef std::vector<std::pair<std::string, std::string>> tokenlist;

    // proprietary functions
    template <typename T>
    void AddAllTokensToElement(std::string tokenID, tokenlist &tokens, T &element);

public:
    // constructor / destructor
    ChatLogic();
    ~ChatLogic();

    // getter / setter
    void SetPanelDialogHandle(ChatBotPanelDialog *panelDialog);
    void SetChatbotHandle(ChatBot *chatbot);

    // proprietary functions
    void LoadAnswerGraphFromFile(std::string filename);
    void SendMessageToChatbot(std::string message);
    void SendMessageToUser(std::string message);
    wxBitmap *GetImageFromChatbot();
};

#endif /* CHATLOGIC_H_ */